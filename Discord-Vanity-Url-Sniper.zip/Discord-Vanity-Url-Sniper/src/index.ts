import Sniper from "./helpers/classes/Sniper";

const sniper = new Sniper();
